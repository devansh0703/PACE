# CMake generated Testfile for 
# Source directory: /home/devansh/kernel_suite/pace-sdk/examples
# Build directory: /home/devansh/kernel_suite/pace-sdk/build-tsan/examples
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
